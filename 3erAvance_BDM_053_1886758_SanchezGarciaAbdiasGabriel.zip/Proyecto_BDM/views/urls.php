
<?php
// urls.php
$baseURL = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);

$homeURL = './dashboard.php';
$myWishlistsURL = './myWishlists.php';
$categoriesURL = './categories.php';
$myChatsURL = './myChats.php';
$myShoppingCartURL = './myShoppingCart.php';
$myShoppingURL = './myShopping.php';
$myProfileURL = './myProfile.php';
?>

